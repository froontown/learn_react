// greeting.js
import React from 'react';
const { div, h2, span} = React.DOM;

export default React.createClass({
//const GreetingComponent = ({greeting}) => (
  displayName: 'GreetingComponent',
  render(){
    return(
    div({classname: 'Greeting'},
      h2({classname: "heading2"}, "Hi"),
      span({classname: "like"},"ReactJS")  
    )
    );
  }
});


/*
class Es6Component extends React.Component {
 render() {
  return <div onClick={this._handleClick}>Hi There, I am learning ES6 in React.</div>;
 }
 _handleClick() {
  console.log("hi");
 }
}
*/

//module.export =  GreetingComponent;
