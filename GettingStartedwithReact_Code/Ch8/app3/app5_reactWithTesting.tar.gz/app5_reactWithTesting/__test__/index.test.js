//require("babel/register");
import expect from 'expect';

 describe('setup',() => {
  it('testing the setup is working', () => {
    expect(true).toEqual(true);
  });
 });
