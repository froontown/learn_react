// __tests__/sum-test.js
//jest.dontMock('../greetings.js');
import expect from 'expect';
import React from 'react';
import TestUtils from 'react-addons-test-utils';
import GreetingComponent from '../greetings.js';


describe('GreetingComponent', () => {
  describe('Common code', () => {
    const renderer = TestUtils.createRenderer();
    renderer.render(React.createElement(GreetingComponent));
    const output = renderer.getRenderOutput();
//    console.log(renderer);
    console.log("From Common Code");
    console.log(output);

//  }
  it('should greet with the greeting Hi', () => {
//    console.log(renderer);
    console.log("h2 component");
    console.log(output);
    expect(output.props.children[0].type).toBe('h2');
    expect(output.props.children[0].props.classname).toBe('heading2');
    expect(output.props.children[0].props.children).toBe('Hi');
  });
  
  it('should return the like as ReactJS', () => {
//    console.log(renderer);
    console.log("span component");
    console.log(output);
    expect(output.props.children[1].type).toBe('span');
    expect(output.props.children[1].props.classname).toBe('like');
    expect(output.props.children[1].props.children).toBe('ReactJS');
  });

});
});

