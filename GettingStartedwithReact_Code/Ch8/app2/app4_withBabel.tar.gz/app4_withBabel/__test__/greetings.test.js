// __tests__/sum-test.js
//jest.dontMock('../greetings');
import expect from 'expect';

describe('greetings', () => {
 it('greets the name', () => {
   var greet = require('../greetings');
   expect(greet("react")).toBe("hi react");
 });
});
