Math.floor((Math.random()*10) + 1);
//return a;
