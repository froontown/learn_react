var expect = require('chai').expect
, name = 'my Name';
var random = require('./index');

describe('setup', function() {
  it('should work!', function() {
    expect(false).to.be.false;
  });
  it ('return my Name', function() {
	expect(name).to.be.a('string');
	expect(name).to.equal('my Name');
	expect(name).to.have.length(7);
	})
});

describe('random', function() { 
	it('should return a random number', function() {
		expect(random).to.equal(9);
	})
})
