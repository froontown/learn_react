// __tests__/sum-test.js
jest.dontMock('../greetings');

describe('greetings', function() {
 it('greets the name', function() {
   var greet = require('../greetings');
   expect(greet("react")).toBe("hi react");
 });
});
