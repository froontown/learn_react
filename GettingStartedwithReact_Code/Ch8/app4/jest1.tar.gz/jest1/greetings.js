// greeting.js
function greetings(name) {
  return "hi "+name;
}
module.exports = greetings;
